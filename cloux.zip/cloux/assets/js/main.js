// For Select 1
let select = document.getElementById("select");
let list = document.getElementById("list");
let selectText = document.getElementById("selectText");
let options = document.getElementsByClassName("options");

list.classList.remove("open");

select.onclick = function(){
    list.classList.toggle("open");
};

for ( let option of options ){
    option.onclick = function() {
        selectText.innerHTML = this.innerHTML;

        setTimeout(function(){
            list.classList.remove("open");
        }, 100);
    };
}

// For Select 2
let select2 = document.getElementById("select2");
let list2 = document.getElementById("list2");
let selectText2 = document.getElementById("selectText2");
let options2 = document.getElementsByClassName("options2");

list2.classList.remove("open");

select2.onclick = function(){
    list2.classList.toggle("open");
};

for ( let option2 of options2 ){
    option2.onclick = function() {
        selectText2.innerHTML = this.innerHTML;

        setTimeout(function(){
            list2.classList.remove("open");
        }, 100);
    };
}

// For Select 3
let select3 = document.getElementById("select3");
let list3 = document.getElementById("list3");
let selectText3 = document.getElementById("selectText3");
let options3 = document.getElementsByClassName("options3");

list3.classList.remove("open");

select3.onclick = function(){
    list3.classList.toggle("open");
};

for ( let option3 of options3 ){
    option3.onclick = function() {
        selectText3.innerHTML = this.innerHTML;

        setTimeout(function(){
            list3.classList.remove("open");
        }, 100);
    };
}